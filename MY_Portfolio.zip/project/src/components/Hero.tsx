import React from 'react';
import Typewriter from 'typewriter-effect';
import { motion } from 'framer-motion';
import { Github, Linkedin, Mail, Phone, FileDown } from 'lucide-react';

const Hero = () => {
  return (
    <section className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-blue-900 to-black text-white p-4">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="max-w-4xl mx-auto text-center"
      >
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1 }}
          className="mb-8"
        >
          <div className="w-32 h-32 mx-auto bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
            <span className="text-4xl">HS</span>
          </div>
        </motion.div>
        
        <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
          Hi, I'm Himanshu Singh
        </h1>
        <div className="text-xl md:text-2xl text-gray-300 mb-8 h-20">
          <Typewriter
            options={{
              strings: [
                'Software Testing Expert',
                'Web Developer',
                'Programmer',
                'Content Writer',
                'Poetry Enthusiast',
                'Technophile'
              ],
              autoStart: true,
              loop: true,
            }}
          />
        </div>
        <motion.div 
          className="flex justify-center space-x-6 mb-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <a href="https://github.com/coderhimanshu2775" target="_blank" rel="noopener noreferrer" 
            className="hover:text-blue-400 transition-all transform hover:scale-110">
            <Github size={24} />
          </a>
          <a href="https://www.linkedin.com/in/himanshu2403" target="_blank" rel="noopener noreferrer" 
            className="hover:text-blue-400 transition-all transform hover:scale-110">
            <Linkedin size={24} />
          </a>
          <a href="mailto:co.himanshu95699@gmail.com" 
            className="hover:text-blue-400 transition-all transform hover:scale-110">
            <Mail size={24} />
          </a>
          <a href="tel:+919569926322" 
            className="hover:text-blue-400 transition-all transform hover:scale-110">
            <Phone size={24} />
          </a>
        </motion.div>
        
        <motion.a
          href="https://drive.google.com/file/d/1JdvG40mslDvUZOGcMQPH2jwr7EbVtyFU/view?usp=sharing"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full text-white font-semibold hover:from-blue-600 hover:to-purple-600 transition-all transform hover:scale-105"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <FileDown className="mr-2" />
          Download Resume
        </motion.a>
      </motion.div>
    </section>
  );
};

export default Hero;
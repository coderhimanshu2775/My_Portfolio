import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const Welcome = ({ onComplete }: { onComplete: () => void }) => {
  const [showWelcome, setShowWelcome] = useState(true);
  const [stars] = useState(() => 
    Array.from({ length: 50 }, () => ({
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 2 + 1,
      duration: Math.random() * 3 + 2
    }))
  );

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowWelcome(false);
      setTimeout(onComplete, 1000);
    }, 6500); // Increased from 3500 to 6500 (added 3 seconds)

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <AnimatePresence>
      {showWelcome && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#020617] overflow-hidden"
        >
          {/* Stars */}
          {stars.map((star, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-white rounded-full"
              initial={{ 
                x: `${star.x}%`, 
                y: `${star.y}%`, 
                scale: 0,
                opacity: 0 
              }}
              animate={{ 
                scale: [0, star.size, 0],
                opacity: [0, 1, 0]
              }}
              transition={{
                duration: star.duration,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          ))}

          {/* Cosmic Portal */}
          <motion.div
            initial={{ scale: 0, rotate: 0 }}
            animate={{ 
              scale: [0, 1.2, 1],
              rotate: [0, 360]
            }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            className="absolute w-64 h-64 rounded-full bg-gradient-to-r from-purple-600 via-blue-500 to-purple-600 opacity-20 animate-pulse"
          />

          <div className="text-center z-10">
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ 
                duration: 0.8,
                delay: 0.5,
                type: "spring",
                stiffness: 200
              }}
              className="mb-8 relative"
            >
              <div className="w-24 h-24 mx-auto bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(147,51,234,0.5)]">
                <span className="text-3xl text-white font-bold">HS</span>
              </div>
              <motion.div
                className="absolute inset-0 w-24 h-24 mx-auto rounded-full"
                initial={{ scale: 1 }}
                animate={{ scale: [1, 1.2, 1] }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                style={{
                  background: 'linear-gradient(to right, rgba(59, 130, 246, 0.2), rgba(147, 51, 234, 0.2))',
                  filter: 'blur(8px)'
                }}
              />
            </motion.div>
            
            <motion.h1
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.8, duration: 0.8 }}
              className="text-4xl md:text-6xl font-bold text-white mb-4"
            >
              Welcome to
            </motion.h1>
            
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 1.2, duration: 0.8 }}
              className="text-3xl md:text-5xl font-bold"
            >
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-purple-500 to-blue-400 animate-gradient">
                Himanshu's World
              </span>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default Welcome;